namespace NEXARC.Web.Views.Shared.Components.ControlSidebar
{
    public class ControlSidebarViewModel
    {
    }
}
